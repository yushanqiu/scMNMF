A=readmatrix('H11.csv');
A=normalize(A,2);
A=A*A';

% [eigenvector,x] = eigs(HH,25);
lambda = diag(x);

[V,D] = eig(A); % 计算矩阵A的特征值D和特征向量V
lambda1 = diag(D);
[D_sorted, idx] = sort(lambda, 'descend'); % 将特征值按照从大到小排序
V_sorted = V(:,idx); % 重新排列特征向量

x = Jocobi_transform(A);

lambda1 = flipud(lambda1)
V_sorted = V(:,idx);

theta = 0.6;
he = 0;
sl = sum(lambda);
for i=1:500
    he = he + lambda(i);
    if he/sl > theta
        k = i;
        break
    end
end

for ii=1:500
    for jj=1:k
        temp(jj) = lambda(jj)*V_sorted(jj,ii);
    end
    beta(ii)=sum(temp);
end
beta = beta';

[beta_sorted, beta_idx] = sort(beta, 'descend');

for i=1:k
    gene(i) = idx(beta_idx(i));
end

x = Jocobi_transform(A)
function B=Jocobi_transform(A)
flag=1;
while(flag)
    B=A;
    n=size(B,1);
    p=1;q=2;
    for i=1:n
        for j=i+1:n
            if(abs(B(i,j))>abs(B(p,q)))%找到对称矩阵的上三角矩阵中最大的元素的下标
                p=i;q=j;
            end
        end
    end
    if(abs(B(p,q))<10^(-9))
        flag=0;%设置精度，达到精度迭代停止
    end
    if(B(p,p)==B(q,q))
        sita=pi/4;
    else
        sita=1/2*atan(2*A(p,q)/(B(q,q)-B(p,p)));
    end
    c=cos(sita);s=sin(sita);
    A([p,q],:)=[c,-s;s,c]*B([p,q],:);%更新p,q行的
    A(:,[p,q])=B(:,[p,q])*[c,s;-s,c];%更新p,q列的
    A([p,q],[p,q])=[c,-s;s,c]*B([p,q],[p,q])*[c,s;-s,c];%更新p行、q行和p列、q列的相交位置的
end
end