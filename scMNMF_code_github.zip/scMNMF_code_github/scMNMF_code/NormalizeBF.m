function [B,F] = NormalizeBF(B,F,NormF,Norm)
    nSmp = size(B,1);
    mFea = size(F,1);

    if Norm == 2
        if NormF
            norms = sqrt(sum(F.^2,1));
            norms = max(norms,1e-10);
            F = F./repmat(norms,nSmp,1);
            B = B.*repmat(norms,mFea,1);
        else
            norms = sqrt(sum(B.^2,1));
            norms = max(norms,1e-10);
            B = B./repmat(norms,nSmp,1);
            F = F.*repmat(norms,mFea,1);
        end
    else
        if NormF
            norms = sum(abs(F),1);
            norms = max(norms,1e-10);
            F = F./repmat(norms,nSmp,1);
            B = B.*repmat(norms,mFea,1);
        else
            norms = sum(abs(B),1);
            norms = max(norms,1e-10);
            B = B./repmat(norms,mFea,1);
            F = F.*repmat(norms,nSmp,1);
        end
    end

end    