function [W_final,H_final,B_final,F_final] = scMNMF(X,p,k1,A,options)
%%%%The model----------------
% You only need to provide the above five inputs.
% Notation:
% X ... (n x J) data matrix 
%       n  ... number of cell sample   
%       J  ... number of genes (feature size)               
% p ... number of feature for dimension reduction
% k1 ... number of features for clustering in NMF(the number of cluster)
% A ... weight matrix of the affinity graph 
%
% options ... Structure holding all settings
%%%
%维度信息
    K = length(X);
%     J = [];
    n = size(X{1},1);
    for i=1:K
        J(i) = size(X{i},2);
    end

%%%%%%%%%%%%------Three initialization methods
    %%%------Random initialization
    for i=1:K
        H0{i} = abs(rand(p,J(i)));
        T{i} = zeros(p,J(i));
    end

    W0 = abs(rand(n,p));
    B0 = abs(rand(n,k1));
    F0 = abs(rand(k1,p));
    T0 = zeros(n,p);
%%%------Initialization by SVD
%     W_sum = zeros(n,p);
%     for i=1:K
%         [U1,vV1,D1] = svds(X{i},p); 
%         W00{i} = abs(U1*sqrt(vV1));  %abs函数是取绝对值
%         H0{i} = abs(sqrt(vV1)*D1');
%         W_sum = W_sum+W00{i};
%         T{i} = zeros(p,J(i));
%     end
%     W0 = W_sum/K;
%     [U1,vV1,D1] = svds(W0,k1); 
%     B0 = abs(U1*sqrt(vV1));  %abs函数是取绝对值
%     F0 = abs(sqrt(vV1)*D1');
%     T0 = zeros(n,p);

%     Ds = zeros(size(A{1}));
%     As = zeros(size(A{1})); %用于求和
%     for i=1:K
%         Dt{i} = diag(sum(A{i},2));  %sum(A,2)：对矩阵A按照行求和
%         Ds = Ds + Dt{i};
%         As = As + A{i};
%     end 
%     Dbar = Ds/K;
%     Abar = As/K;
%     L = D-A;

    W = W0; H = H0; B = B0; F = F0;
    E = W;
    C = H;
  
    %%%-------
    iter = 0; 
    converged = 0;    
    OmaxIter = 30; ImaxIter = 50; 
    tol1 = 1e-5;tol2 = 1e-5;
    tryNo = 0;
    w1 = 1;w2 = 1;
    
%     cond1=zeros(ImaxIter,OmaxIter);
%     ERRH=zeros(K,ImaxIter,OmaxIter);

    Abar = zeros(size(A{1}));
    for i=1:K
        Abar = Abar + double(A{i});
    end
    Dbar = diag(sum(Abar,2));

while ~converged  && iter < OmaxIter   % 逻辑与

    derta = 0.05;
    miu = 0.5; 
    iter = iter + 1;
    % 参数设置参照DRJCC
    for i=1:K
        lambda{i} = norm(X{i},'fro') / norm(H{i},'fro');
%         lambda{i} = 0.5;
    end
    alpha1 = norm(W,'fro') / norm(B,'fro');
%     alpha1 = 0.5;

    %%%========Update variables W==========
    iter_W=0;
    while iter_W<ImaxIter
        iter_W = iter_W + 1;
        V1 = zeros(size(W));
        V2 = zeros(p);
        I = eye(p); % 返回p*p单位矩阵
        for i=1:K
            V1 = V1 + X{i}*H{i}';
            V2 = V2 + H{i}*H{i}';
        end
        VV1 = 2*V1+2*B*F+derta*E+T0;  % 分子
        VV2 = W*(2*V2+2*I+derta*I);   % 分母
        W_raw = W;
        W = W.*(VV1./VV2+eps);
	    W = max(W,0);
        W_pro = W;
        E_raw = E;
        E = soft(W-T0/derta,miu/derta);
	    T0 = T0 + 1.618*derta*(E-W);
        cond1(iter,iter_W)=norm(E-W,"inf");%观察收敛速度

        if norm(E-W,"inf")<tol2
            break;
        end
        
    end

	%%%========Update variables H==========
    iter_H=0;
    while iter_H<ImaxIter
        iter_H = iter_H + 1;
        H_raw = H;
        for i=1:K
            M{i} = 2*W'*X{i}+derta*C{i}+T{i};
            N{i} = 2*W'*W*H{i} + derta*H{i};
            H{i} = H{i}.*(M{i}./N{i}+eps);% eps是精度
        end
        H_pro= H;
        C_raw = C;
        for i=1:K
            C{i} = soft(H{i}-T{i}/derta,lambda{i}/derta);
            T{i} = T{i} + 1.618*derta*(C{i}-H{i});
            ERRH(i,iter_H,iter)=norm(C{i}-H{i},'inf');
        end
        if max(ERRH(:,iter_H,iter))<tol1
            break;
        end
        
    end

	%%%%% Update variables B and F 
%     
	%%%========Update variables B==========
    B_raw = B;
	B1 = w2*W*F' + alpha1*Abar*B;
	B2 = w2*B*F*F' + alpha1*Dbar*B;
%   B1 = w2*W*F'; %without 拉普拉斯正则化项
% 	B2 = w2*B*F*F';

	B = B.*(B1)./(B2);
    B = max(B,0);
    B_pro = B;
	%%%========Update variables F========== 
    F_raw = F;
	F = F.*(w2*B'*W)./(w2*B'*B*F+eps);
	F = max(F,0);
	F_pro = F;
%     for i=1:K
%         errH(i) = norm(H_pro{i}-H_raw{i},'fro');
%         errX(i) = norm(X{i},'fro');
%     end
% 	temp = max ([[norm(W_pro-W_raw,'fro'),norm(F_pro-F_raw,'fro'),norm(B_pro-B_raw,'fro')],errH]);
    temp = norm(B_pro-B_raw,'fro');
    %     temp = muu*temp/norm(V,2);
%     temp =temp/max(errX);

	if temp < tol1 
        converged = 1;
    end
    
    disp([' 迭代次数 ' num2str(iter) ' temp ' num2str(temp) ]);

    t1(iter)=temp;

end %%(对应于while的end)
 
    W_final = W; %%% A_final  is finally W  
    H_final = H; %%% H_final  is finally H 
    B_final = B; %%% B_final  is finally B
    F_final = F; %%% F_final  is finally F

	
end %%(对应于scMNMF函数的end)


function[y] = soft( x, T )
  if sum( abs(T(:)) )==0
       y = x;
  else
       y = max( abs(x) - T, 0);
       y = sign(x).*y;
   end
end   
