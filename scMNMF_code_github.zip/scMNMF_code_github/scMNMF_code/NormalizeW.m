function [W] = NormalizeW(W,NormW,Norm)
    
    nSmp = size(W,1);
    if Norm == 2
        if NormW
            norms = sqrt(sum(H.^2,1));
            norms = max(norms,1e-10);
            H = H./repmat(norms,nSmp,1);
            W = W.*repmat(norms,mFea,1);
        else
            norms = sqrt(sum(W.^2,1));
            norms = max(norms,1e-10);
            W = W./repmat(norms,nSmp,1);
        end
    else
        if NormW
            norms = sum(abs(H),1);
            norms = max(norms,1e-10);
            W = W.*repmat(norms,mFea,1);
        else
            norms = sum(abs(W),1);
            norms = max(norms,1e-10);
            W = W./repmat(norms,mFea,1);
        end
    end

end    