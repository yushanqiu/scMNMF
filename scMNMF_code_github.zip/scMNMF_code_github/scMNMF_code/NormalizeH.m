function [H] = NormalizeH(W,H,NormH,Norm)

    mFea = size(H,1);
    if Norm == 2
        if NormH
            norms = sqrt(sum(H.^2,1));
            norms = max(norms,1e-10);
            H = H./repmat(norms,nSmp,1);
        else
            norms = sqrt(sum(W.^2,1));
            norms = max(norms,1e-10);
            H = H.*repmat(norms,mFea,1);
        end
    else
        if NormH
            norms = sum(abs(H),1);
            norms = max(norms,1e-10);
            H = H./repmat(norms,nSmp,1);
            W = W.*repmat(norms,mFea,1);
        else
            norms = sum(abs(W),1);
            norms = max(norms,1e-10);
            W = W./repmat(norms,mFea,1);
            H = H.*repmat(norms,nSmp,1);
        end
    end

end    