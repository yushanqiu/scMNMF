	clear all;
    clc;
%     load('BMNC.mat')
%     load('MAGE.mat')
%     load('10x10kpbmc.mat') 
%     load('10x10kk.mat')
%     load('spleen.mat')
%     load('spector.mat')
	load('Sim1.mat')
	
    K=length(P);%number of omics_data
    for i=1:K   
        X{i}=P{i};
    end
    %==============Constructing a weight matrix==============
    %Preset value before constructing weight matrix
    options = [];
    option.Metric = 'Euclidean';
    options.NeighborMode = 'KNN';%KNN
    options.k =5;%5 nearest neighbors
    options.WeightMode = 'Cosine';%Weights are 0 or 1, it can eplace with 'HeatKernel', 'Euclidean' 
    for i=1:K
        A{i} = constructA(X{i},options);
    end
    
    clear options;
    options = [];
    p=25; k1=length(unique(real_label));
    %%%%%%%%%%%%%%p is the number of feature for dimension reduction
    %%%%%%%%%%%%%%example: 20,50, 100, 500
    %%%%%%%%%%%%%%k1 is the number of features for clustering in NMF(the number of cluster)
    [W_final,H_final,B_final,F_final] = scMNMF(X,p,k1,A,options); %% Call the main function to solve the variables

    for e=1:size(B_final,1)
    v=B_final(e,:);
    ma=max(v);
    [s,t]=find(v==ma);
    l(e)=t;
    end

    %%%%%%%%%%%%%%==================Performance evaluation===============================
    ll=real_label;%%%  the label originally identified by the authors
    l=l';%%% Labels obtained by DRjCC
    [newl] = bestMap(ll,l);%% Permute label of l to match ll as good as possible
    nmi=compute_NMI(ll,newl); %% Calculating the Normalized Mutual Information (NMI)
    ami=AMI(ll,newl);%% Calculating the Adjusted Mutual Information (AMI)
    ari = ARI(ll,max(ll),newl,max(newl)); %% Calculating the Adjusted Rand Index (ARI)
    pre_label =newl;
    if ~isempty(ll) 
    exact = find(pre_label == ll);
    accuracy = length(exact)/length(newl); %% Calculating the accuracy
    else
    accuracy = [];
    end
