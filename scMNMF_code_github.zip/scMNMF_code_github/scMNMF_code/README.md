scMNMF

A novel method for single-cell multi-omics clustering based on matrix factorization
Author: Guo dong: guadong0106@163.com Maintainer: Yushan Qiu: yushan.qiu@szu.edu.cn 

scMNMF is written in the MATLAB programming language. To use, please download the scMNMF folder and follow the instructions provided in the README.

Files：

scMNMF.m - The main function.

main_scMNMF.m - A script with a single-cell multi-omics data to show how to run the code.

Sim1.mat - A simulated single-cell multi-omics data used in the cell type clustering example. The dataset has been preprocessed.

constructA.m - Compute adjacent matrix A.

NormalizeBF.m - Normalize data.

NormalizeW.m - Normalize data.

NormalizeH.m - Normalize data.

bestMap.m - permute labels of L2 to match L1 as good as possible.

compute_NMI.m - Program for calculating the Normalized Mutual Information (NMI) between two clusterings.

AMI.m - Program for calculating the Adjusted Mutual Information (AMI) between two clusterings.

ARI.m - Program for calculating the Adjusted Rand Index ( Hubert & Arabie) between two clusterings.

hungarian.m - Solve the Assignment problem using the Hungarian method.

selectgene.m - select information genes.


